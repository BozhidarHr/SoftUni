// MAKE FOLDERS
// 1. npm install
// 2. npm install lit-html 
// 3. npm install page.js
// 4. npm start
// 5. load script!, type module
// 6. NE ZABRAVQI .js !!
//7. Dobavqme putishtata v html-a i na logout pishem "javascript:void(0)" i mu slagame id="logoutBtn" 
// - example - <a id="logoutBtn" href="javascript:void(0)">Logout</a>
// kato v template imame danni si pravim get zaqvka otdelno i posle funkciqta na template e async (check memes i catalog)